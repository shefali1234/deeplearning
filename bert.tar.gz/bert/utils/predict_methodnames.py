from tokenizers.implementations import ByteLevelBPETokenizer
from transformers import pipeline
from transformers import RobertaForMaskedLM

def get_predicted_methodname(result):
    codestring = result['sequence']
    parts = codestring.split()
    try:
        firstidx = parts.index("(")
    except:
        return "None"
    print(" ".join(parts[firstidx-2:firstidx+2]))
    return parts[firstidx-1]

# CONFIGURATION OPTIONS
CONFIG_NAME = "robertaconfig1"
INPUT_FILE = "../data/javaspacedcodes"
MAX_LENGTH = 512

fill_mask = pipeline("fill-mask", model=CONFIG_NAME, tokenizer=CONFIG_NAME)

outf = open("./methodnamepredictions", 'w')
count = 0
with open("../data/javavalidspacedcodes", "r") as f:
    for line in f:
        parts = line.strip().split()
        try:
            firstidx = parts.index("(")
        except:
            print(line)
            continue
        methodname = parts[firstidx-1]
        print()
        print(" ".join(parts[firstidx-2:firstidx+2]))
        parts[firstidx - 1] = "<mask>"
        text = " ".join(parts)
        try:
            result = fill_mask(text)
        except:
            print("filling:", text)
            continue

        predictions = []
        for r in result:
            mname = get_predicted_methodname(r)
            predictions.append(mname)
        
        print(methodname + " " + ",".join(predictions), file=outf)
        count +=1
        if count % 100 == 0:
            print("Num:", count)

outf.close()