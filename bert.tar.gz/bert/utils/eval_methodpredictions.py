import sys

inpfilename = sys.argv[1]

exactmatch = 0
partialmatch = 0
count = 0.

with open(inpfilename, "r") as f:
    for line in f:
        parts = line.split()
        realname = parts[0]
        predictions = parts[1].split(",")

        partialfound = False
        realFound = False
        for p in predictions:
            if realname == p:
                exactmatch += 1
                realFound = True
                break
            elif realname in p or p in realname:
                partialfound = True
                
        if not realFound and partialfound:
            partialmatch += 1
        count += 1

print("Total Predictions:", count)
print("Exact Match:", exactmatch, " = ", (exactmatch/count), "%")
print("Partial Match:", partialmatch, " = ", (partialmatch/count), "%")