import argparse
import configparser

def add_arguments(parser):
    parser.add_argument('configfile', help='Config File to use')
    parser.add_argument('--workdir', dest='work_dir', help='Working Directory')
    parser.add_argument('--trainfile', dest='train_file', help='Training file path')
    parser.add_argument('--validfile', dest='valid_file', help='Validation file path')
    parser.add_argument('--model', dest='modeltype', help='Model type')
    parser.add_argument('--tok', dest='tokenizer', help='Tokenizer')
    parser.add_argument('--retraintok', dest='retrain_tok', help='Retrain Tokenizer')
    parser.add_argument('--vocabsize', dest='vocabsize', help='Vocab Size', type=int)
    parser.add_argument('--maxlen', dest='inp_maxlen', help='Max input length', type=int)
    parser.add_argument('--minfreq', dest='min_freq', help='Min frequency for vocab', type=int)
    parser.add_argument('--maxposemb', dest='max_pos_emb', help='Max positional embeddings to use', type=int)
    parser.add_argument('--numattn', dest='num_attn_heads', help='Num Attention heads', type=int)
    parser.add_argument('--numhid', dest='num_hid_layers', help='Num blocks', type=int)
    parser.add_argument('--blocksize', dest='block_size', help='Data block size', type=int)
    parser.add_argument('--epochs', dest='epochs', help='Num epochs to train for', type=int)
    parser.add_argument('--batchsize', dest='batch_size', help='Batch size', type=int)

    return parser

def read_config(filename, args):
    config = configparser.ConfigParser()
    config.read(filename)

    confmap = {}
    for sec in config.sections():
        for k in config[sec]:
            if sec == 'MAIN':
                confmap[k] = config[sec][k]
            else:
                confmap[k] = int(config[sec][k])
    
    for k in confmap:
        if k in args.__dict__.keys():
            newvalue = args.__dict__[k]
            if newvalue is not None:
                confmap[k] = args.__dict__[k]
    confmap['retrain_tok'] = confmap['retrain_tok'].lower()=='true'
    return confmap