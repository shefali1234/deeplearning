# Takes in the entire json file from CodeSearchNet and joins all the code tokens to form a single input line
import sys
import json
import re
inp_file = sys.argv[1]
out_file = sys.argv[2]

outf = open(out_file, "w")

counter = 0
with open(inp_file, "r") as f:
    for line in f:
        data = json.loads(line)
        code_tokens = data['code_tokens']
        code_str = " ".join(code_tokens)
        code_str = re.sub("\s+", " ", code_str)
        print(code_str,  file=outf)
        counter += 1
outf.close()
print("Wrote", counter, "lines to the output file.")