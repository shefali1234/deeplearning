from tokenizers.implementations import ByteLevelBPETokenizer
from transformers import pipeline
from transformers import RobertaForMaskedLM

# CONFIGURATION OPTIONS
CONFIG_NAME = "robertaconfig1"
INPUT_FILE = "../data/javaspacedcodes"
MAX_LENGTH = 512

# tokenizer = ByteLevelBPETokenizer()
# tokenizer = ByteLevelBPETokenizer(CONFIG_NAME+"/vocab.json", CONFIG_NAME+"/merges.txt")


fill_mask = pipeline("fill-mask", model=CONFIG_NAME, tokenizer=CONFIG_NAME)
text = "private void startDraining ( boolean overflow ) { byteBuffer . flip ( ) ; if ( overflow && byteBuffer . remaining ( ) == 0 ) { byteBuffer = ByteBuffer . allocate ( byteBuffer . capacity ( ) * 2 ) ; } else { draining = true ; } }"
result = fill_mask(text)

for r in result:
    print(r)