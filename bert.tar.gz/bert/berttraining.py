import argparse
import shutil
from tokenizers.implementations import ByteLevelBPETokenizer, BertWordPieceTokenizer, SentencePieceBPETokenizer, CharBPETokenizer
from tokenizers.processors import BertProcessing
from transformers import RobertaConfig, RobertaTokenizerFast, RobertaForMaskedLM
from transformers import LineByLineTextDataset
from transformers import DataCollatorForLanguageModeling
from transformers import Trainer, TrainingArguments
from utils import generalutils

parser = argparse.ArgumentParser(description='Huggingface Model Training')
generalutils.add_arguments(parser)
args = parser.parse_args()

configfile = args.configfile
conf = generalutils.read_config(configfile, args)

print(conf)

# Training the tokenizer
if conf.retrain_tok:
    if conf.tokenizer == "bpe":
        tokenizer = ByteLevelBPETokenizer()
    elif conf.tokenizer == "wordpiece":
        tokenizer = BertWordPieceTokenizer()
    elif conf.tokenizer == "sentencepiece":
        tokenizer = SentencePieceBPETokenizer()
    elif conf.tokenizer == "charbpe":
        tokenizer = CharBPETokenizer()
    tokenizer.train(files=[conf.train_file], vocab_size=conf.vocabsize, min_frequency=conf.min_freq, special_tokens=["<s>","<pad>","</s>","<unk>","<mask>","<cls>", "<sep>"])
    tokenizer.save(conf.work_dir)
else:
    if conf.tokenizer == "bpe":
        tokenizer = ByteLevelBPETokenizer(conf.work_dir+"/vocab.json", conf.work_dir+"/merges.txt")
    elif conf.tokenizer == "wordpiece":
        tokenizer = BertWordPieceTokenizer(conf.work_dir+"/vocab.json", conf.work_dir+"/merges.txt")
    elif conf.tokenizer == "sentencepiece":
        tokenizer = SentencePieceBPETokenizer(conf.work_dir+"/vocab.json", conf.work_dir+"/merges.txt")
    elif conf.tokenizer == "charbpe":
        tokenizer = CharBPETokenizer(conf.work_dir+"/vocab.json", conf.work_dir+"/merges.txt")

# Enable adding of BERT special tokens
tokenizer._tokenizer.post_processor = BertProcessing(("</s>", tokenizer.token_to_id("</s>")), ("<cls>", tokenizer.token_to_id("<cls>")))
tokenizer.enable_truncation(max_length=conf.inp_maxlen)

# Define model config
mdlconfig = RobertaConfig(vocab_size=conf.vocabsize, max_position_embeddings=conf.max_pos_emb, num_attention_heads=conf.num_attn_heads, 
                            num_hidden_layers=conf.num_hid_layers,type_vocab_size=1)

# Init tokenizer
tokenizer = RobertaTokenizerFast.from_pretrained(conf.work_dir, max_len=conf.inp_maxlen)

# Init model
model = RobertaForMaskedLM(config=mdlconfig)
print("Num model paramters:", model.num_parameters())

# Create the dataset
dataset = LineByLineTextDataset(tokenizer=tokenizer, file_path=conf.train_file, block_size=conf.block_size)
# Data Collator
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=True, mlm_probability=0.15)

# Training
training_args = TrainingArguments(output_dir=conf.workdir, overwrite_output_dir=True, num_train_epochs=conf.epochs, 
                                    per_gpu_train_batch_size=conf.batch_size, save_steps=10_000, save_total_limit=2)
trainer = Trainer(model=model, args=training_args, data_collator=data_collator, train_dataset=dataset, prediction_loss_only=True)

trainer.train()

trainer.save_model(conf.work_dir)

# Save the config to the model directory so we know what config was used for this model
with open(conf.work_dir+"/config_used", "w") as f:
    print(conf, file=f)